﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerController2 : MonoBehaviour
{
    public float moveSpeed = 30;
	
	public float moveSpeedUpDown = 1;

    public float turnSpeed = 20;

    public float gravitySwitch = 1;
	
    private Vector3 moveDirection;
	
	private CharacterController _controller;

	private float gravity = 0;
	
	void Start(){
		_controller = GetComponent<CharacterController>();
	}
	
    void Update()
    {
        moveDirection = Vector3.zero;

	    gravity -= 9.81f * Time.deltaTime * gravitySwitch;
		_controller.Move(new Vector3(0, gravity, 0));
		if (_controller.isGrounded ) gravity = 0;
		
		//moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		//_controller.Move(moveDirection * Time.deltaTime * moveSpeed);
        
		
		if (Input.GetKey(KeyCode.LeftArrow))
            transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.RightArrow))
            transform.Rotate(Vector3.up, - turnSpeed * Time.deltaTime);
		
        if (Input.GetKey(KeyCode.UpArrow)){
            moveDirection = transform.TransformDirection(Vector3.forward * moveSpeed) ;
            _controller.SimpleMove(moveDirection * Time.deltaTime);
		}

		if (moveDirection != Vector3.zero)
            transform.forward = moveDirection;
		
		if (Input.GetKey(KeyCode.DownArrow)){
            moveDirection = transform.TransformDirection(- Vector3.forward * moveSpeed);
            _controller.SimpleMove(moveDirection * Time.deltaTime);
		}
		
		 if (Input.GetKey(KeyCode.O)){
            moveDirection = transform.TransformDirection(-Vector3.up * moveSpeedUpDown);
            _controller.Move(moveDirection * Time.deltaTime);
		 }
		
		 if (Input.GetKey(KeyCode.P)){
            moveDirection = transform.TransformDirection(Vector3.up * moveSpeedUpDown);
            _controller.Move(moveDirection * Time.deltaTime);
		 }
		
		
    }
}