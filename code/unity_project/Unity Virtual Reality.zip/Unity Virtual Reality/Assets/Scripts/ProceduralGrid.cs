﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

[RequireComponent (typeof(MeshFilter), typeof(MeshRenderer))]
public class ProceduralGrid : MonoBehaviour {

    Mesh mesh;
    Renderer renderer;
    Vector3[] vertices;
    Vector2[] uvs;
    int[] triangles;
    
    //grid settings
    public float cellSize = 1;
    public Vector3 gridOffset;
    public Vector2 gridSize = new Vector2(1,1);
	public float angle_offset;
    
	public bool rotationEnable;
    public Material material;

	// Use this for initialization
    void Start(){
        mesh = GetComponent<MeshFilter>().mesh;
        renderer = GetComponent<MeshRenderer>();
		MakeContiguousProceduralSphericalGrid(angle_offset);
        UpdateMesh();  
    }
    
    void Update(){
		if(rotationEnable) transform.eulerAngles = new Vector3(-(float)GameObject.FindGameObjectsWithTag("Player")[0].transform.eulerAngles.y-270f, 0f, -90f);
		
		//float a = transform.eulerAngles.y;
		//float b = (float)GameObject.FindGameObjectsWithTag("Player")[0].transform.eulerAngles.y;
		//if(a > b) transform.Rotate(new Vector3(0f,(Mathf.Lerp(b,a,0.5f)),0f));
		//else      transform.Rotate(new Vector3(0f,(Mathf.Lerp(a,b,0.5f)),0f));
		
		//MakeContiguousProceduralSphericalGrid(((float)GameObject.FindGameObjectsWithTag("Player")[0].transform.eulerAngles.y +90) %360);
        //UpdateMesh();
		//SwapUVs((float)GameObject.FindGameObjectsWithTag("Player")[0].transform.eulerAngles.y %360);
        SetMaterial();
    }
	
	void SwapUVs(float angle){
		Vector2[] uvs_tmp = uvs;
		for(int x = 0; x < uvs_tmp.Length; x++){
			uvs_tmp[x] += new Vector2(angle/360f, 0f);
		}
		uvs = uvs_tmp;
	}
    void MakeDiscreteProceduralGrid(){
        //set array sizes
        vertices = new Vector3[(int)(gridSize.x * gridSize.y * 4)];
        triangles = new int[(int)(gridSize.x * gridSize.y * 6)];
        
        //set tracker integers
        int v = 0;
        int t = 0;
        
        //set vertex offset
        float vertexOffset = cellSize * 0.5f;
        
        for(int x = 0; x < gridSize.x;x++){
            for(int y = 0; y < gridSize.y;y++){
                Vector3 cellOffset = new Vector3(x * cellSize,0,y * cellSize);
                
                //populate vertices and triangles
                vertices[v]   = new Vector3(-vertexOffset,0,-vertexOffset) + cellOffset + gridOffset;
                vertices[v+1] = new Vector3(-vertexOffset,0, vertexOffset) + cellOffset + gridOffset;
                vertices[v+2] = new Vector3( vertexOffset,0,-vertexOffset) + cellOffset + gridOffset;
                vertices[v+3] = new Vector3( vertexOffset,0, vertexOffset) + cellOffset + gridOffset;
                
                triangles[t]   = v;
                triangles[t+1] = triangles[t+4] = v+1;
                triangles[t+2] = triangles[t+3] = v+2;
                triangles[t+5] = v+3;
                
                v += 4;
                t += 6;
            }
        }
    }
        
    void MakeContiguousProceduralGrid(){
        //set array sizes
        vertices = new Vector3[(int)((gridSize.x+1) * (gridSize.y+1))];
        triangles = new int[(int) (gridSize.x * gridSize.y * 6)];
        
        //set tracker integers
        int v = 0;
        int t = 0;
        
        //set vertex offset
        float vertexOffset = cellSize * 0.5f;
        
        //create vertex grid
        for(int x = 0; x <= (int)(gridSize.x); x++){
            for(int y = 0; y <= (int)(gridSize.y); y++){
                vertices[v] = new Vector3(x * cellSize - vertexOffset,0,y * cellSize - vertexOffset) + gridOffset;
                v++;
            }
        }
        
        
        float max_x = vertices.OrderByDescending(x => x.x).First().x;
        float max_y = vertices.OrderByDescending(x => x.z).First().z;
        
        uvs = new Vector2[vertices.Length];

        for (int i = 0; i < uvs.Length; i++)
        {
            uvs[i] = new Vector2(vertices[i].x/max_x, vertices[i].z/max_y);
        }
        
        //reset vertex tracker
        v = 0;
        
        //setting each cell's triangles
        for(int x = 0; x < (int)(gridSize.x); x++){
            for(int y = 0; y < (int)(gridSize.y); y++){
                triangles[t]   = v;
                triangles[t+1] = triangles[t+4] = v + 1;
                triangles[t+2] = triangles[t+3] = v + (int)(gridSize.y+1);
                triangles[t+5] = v + (int)(gridSize.y+1) + 1;
                v++;
                t += 6;
            }
            v++;
        }
    }
    
    void MakeContiguousProceduralSphericalGrid(float start_angle = 0f){
         //set array sizes
        vertices = new Vector3[(int)((gridSize.x+1) * (gridSize.y+1))];
        uvs = new Vector2[vertices.Length];
        triangles = new int[(int) (gridSize.x * gridSize.y * 6)];
        
        
        //set tracker integers
        int v = 0;
        int t = 0;
        
        //set vertex offset
        float vertexOffset = cellSize * 0.5f;
        
        //create vertex grid
        for(int x = 0; x <= (int)(gridSize.x); x++){
            float theta = (start_angle + (360f/gridSize.x) * x) * Mathf.Deg2Rad;
            for(int y = 0; y <= (int)(gridSize.y); y++){
				int radius = y;
				float x2 = radius*Mathf.Sin(theta);
				float y2 = radius*Mathf.Cos(theta);
				vertices[v] = new Vector3(x2 * cellSize - vertexOffset,0,y2 * cellSize - vertexOffset) + gridOffset;
				uvs[v] = new Vector2((float)x/gridSize.x, (float)y/(gridSize.y));
				v++;
            }
        }       
        
        //reset vertex tracker
        v = 0;
        
        //setting each cell's triangles
        for(int x = 0; x < (int)(gridSize.x); x++){
            for(int y = 0; y < (int)(gridSize.y); y++){
				triangles[t]   = v;
				triangles[t+1] = triangles[t+4] = v + 1;
				triangles[t+2] = triangles[t+3] = v + (int)(gridSize.y+1);
				triangles[t+5] = v + (int)(gridSize.y+1) + 1;
                v++;
                t += 6;
            }
            v++;
        }
    }
    
    void UpdateMesh(){
        mesh.Clear();
        
        mesh.vertices = vertices;
        
        mesh.triangles = triangles;
        
        mesh.uv = uvs;
        mesh.RecalculateNormals();
    }
    
    void SetMaterial(){
        renderer.material = material;
    }
}

